<?php

use App\Http\Controllers\Dashboard\WardenDashboardController;

Route::middleware(['auth', 'role:Hostel Warden'])->group(function () {
    Route::get('/warden/dashboard', [WardenDashboardController::class, 'index'])->name('warden.dashboard');

    // Add other warden-specific routes here
});
