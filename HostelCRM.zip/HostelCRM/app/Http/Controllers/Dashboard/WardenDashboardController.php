<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;

class WardenDashboardController extends Controller
{
    public function index()
    {
        return view('dashboards.warden');
    }




    
}
