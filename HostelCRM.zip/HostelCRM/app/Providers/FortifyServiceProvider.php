<?php

namespace App\Providers;

use App\Http\Responses\LoginResponse;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\ServiceProvider;
use Laravel\Fortify\Contracts\LoginResponse as LoginResponseContract;
use Laravel\Fortify\Fortify;

class FortifyServiceProvider extends ServiceProvider
{
    // ...

    public function register(): void
    {
        // Bind your custom LoginResponse here
        $this->app->singleton(
            LoginResponseContract::class,
            LoginResponse::class
        );
    }
    
    // ...
}
